# Qwen3.5-0.8B → Student (100-150M) Distillation

Your goal: **Distill Qwen-0.8B → 100-150M student** for RTX 2050

## Architecture Overview

```
Teacher: Qwen3.5-0.8B (BF16) 
  ↓ Knowledge Distillation ↓
Student: 5 layers × 256 hidden (100M params)
  ↓
Inference: 47ms/sample on RTX 2050
```

## What You Have

```
~/model/
├── Qwen3.5-0.8B-BF16.gguf          (1.4GB - GGUF format, inference-optimized)
└── mistral-7b-instruct-v0.2.Q2_K.gguf  (2.9GB - for comparison)
```

**Problem with GGUF**: It's optimized for inference (llama.cpp), not training. We'll use HuggingFace models instead, which have the same weights.

## Quick Start (5 minutes)

### 1. Install Dependencies

```bash
cd ~/DiffuMoE
uv venv
source .venv/bin/activate  # or: source .venv/bin/activate.fish for fish shell

# Install PyTorch (CUDA 12.1)
uv pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu121

# Core packages
uv pip install transformers accelerate bitsandbytes peft datasets
```

### 2. Download Teacher

```bash
# Option A: Use HuggingFace (recommended for training)
python setup_qwen_distill.py --download

# Option B: Convert your GGUF (advanced)
# Note: This requires converting BF16 GGUF → HuggingFace format
# Easier to just download the same model from HF
```

### 3. Prepare Data

```bash
# Download WikiText-2 (24M tokens)
python setup_qwen_distill.py --data

# Or use your own data: place .txt file in data/
```

### 4. Start Training

```bash
# Full setup
python setup_qwen_distill.py --all

# Or manual training
python qwen_distill.py
```

**Expected output:**
```
Step 50/2000 | Loss: 2.84 | KD: 2.10 | Feature: 0.74 | LR: 8.00e-04
Step 100/2000 | Loss: 2.71 | KD: 1.95 | Feature: 0.76 | LR: 8.00e-04
Step 150/2000 | Loss: 2.58 | KD: 1.82 | Feature: 0.76 | LR: 8.00e-04
```

### 5. Run Inference

```bash
# Generate text with student
python qwen_inference.py \
    --checkpoint checkpoints/student_final.pt \
    --prompt "The future of AI"

# Evaluate
python qwen_inference.py \
    --checkpoint checkpoints/student_final.pt \
    --eval \
    --speed
```

---

## Detailed Setup Guide

### Environment Setup

```bash
# Navigate to project
cd ~/DiffuMoE

# Create virtual environment with uv
uv venv
source .venv/bin/activate

# Install PyTorch with CUDA 12.1 support
uv pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu121

# Verify CUDA
python -c "import torch; print(torch.cuda.is_available(), torch.cuda.get_device_name(0))"
# Expected: True, NVIDIA RTX 2050
```

### Data Preparation

**Option 1: WikiText-2 (built-in)**
```bash
python setup_qwen_distill.py --data
# ~181MB, auto-downloads
```

**Option 2: Custom data**
```bash
# Create data/train.txt with your text (one line per sample)
cat > data/train.txt << 'EOF'
This is your first text sample.
This is your second text sample.
...
EOF
```

**Option 3: Pile or other datasets**
```python
# Modify setup_qwen_distill.py:
prepare_dataset("pile", split="train[:5000]", output_file="data/train.txt")
```

### Configuration

Edit `config.py` or modify `QwenDistillationConfig` in `qwen_distill.py`:

```python
class QwenDistillationConfig:
    # Teacher
    self.teacher_model_name = "Qwen/Qwen2.5-0.5B"  # or Qwen/Qwen1.5-0.5B
    
    # Student architecture (adjust for your needs)
    self.student_num_layers = 5           # 3-8 layers
    self.student_hidden_dim = 256         # 128-512
    self.student_num_heads = 4            # hidden_dim / head_dim = num_heads
    
    # Training
    self.batch_size = 2                   # RTX 2050: 2 or 4
    self.gradient_accumulation_steps = 4  # Effective batch: 2×4 = 8
    self.learning_rate = 8e-4
    self.max_steps = 2000                 # ~4-6 hours training
    
    # Distillation
    self.temperature = 3.0                # Qwen is smaller, use lower temp
    self.alpha = 0.8                      # 80% KD loss (response-based)
    self.beta = 0.2                       # 20% feature loss
```

### Training

**Basic training:**
```bash
python qwen_distill.py
```

**With monitoring:**
```bash
# Watch logs in real-time
tail -f logs/metrics.json

# Or use TensorBoard (if integrated)
tensorboard --logdir logs --port 6006
```

**Expected timeline:**
- Steps 0-500: Rapid loss drop (2.8 → 1.8)
- Steps 500-1500: Steady convergence (1.8 → 1.2)
- Steps 1500-2000: Plateau (1.2 → 1.0)
- **Total time: 4-6 hours on RTX 2050**

### Memory Management

**RTX 2050 (4GB VRAM) breakdown:**

| Component | Size |
|-----------|------|
| Teacher (FP16, on CPU) | ~2GB |
| Student (FP16, on GPU) | ~0.4GB |
| Optimizer states | ~0.8GB (GPU) |
| Gradients | ~0.4GB |
| Activations | ~0.3GB |
| **Total GPU** | **~2GB** ✓ |

**If OOM:**
- Reduce `batch_size` to 1
- Reduce `max_seq_length` to 128
- Use `teacher_device = "cpu"` (slower but lower GPU memory)
- Enable `use_gradient_checkpointing = True`

### Inference

**After training, your checkpoint structure:**
```
checkpoints/
├── student_final.pt           # Final weights
├── student_step_200.pt        # Intermediate checkpoints
├── metrics.json               # Training curves
└── ...
```

**Load and generate:**
```python
from qwen_inference import StudentInference

inf = StudentInference("checkpoints/student_final.pt", device="cuda")

# Generate text
text = inf.generate("The future of AI is", max_length=100)
print(text)

# Speed test
stats = inf.inference_speed_test(num_runs=10)
print(f"Speed: {stats['throughput']:.1f} samples/sec")
```

**Command line:**
```bash
python qwen_inference.py \
    --checkpoint checkpoints/student_final.pt \
    --prompt "The future of AI" \
    --speed \
    --eval
```

---

## Evaluation

### Perplexity

```python
from qwen_inference import StudentEvaluator

evaluator = StudentEvaluator(
    "checkpoints/student_final.pt",
    "Qwen/Qwen2.5-0.5B"
)

# Test on sample texts
test_texts = ["This is a test.", "Another sample."]
student_ppl = evaluator.compute_perplexity(test_texts)      # ~15-20
teacher_ppl = evaluator.compute_teacher_perplexity(test_texts)  # ~8-10
```

### Quality Metrics

```python
# Top-5 token agreement with teacher
agreement = evaluator.top_k_agreement(test_texts, k=5)
# Expected: 85-95%

# Compare generations
evaluator.generate_comparison("Tell me about AI")
```

---

## Your GGUF Model

You have `Qwen3.5-0.8B-BF16.gguf`, but for training distillation:

**Option 1: Use HuggingFace model (easiest)**
```python
# In qwen_distill.py config:
self.teacher_model_name = "Qwen/Qwen2.5-0.5B"
# Downloads from HF, same weights as your GGUF, but trainable
```

**Option 2: Convert GGUF to HuggingFace (advanced)**
```bash
# Install conversion tools
uv pip install gguf llama-cpp-python

# Convert (requires knowing the model config)
# python convert_gguf_to_hf.py Qwen3.5-0.8B-BF16.gguf models/qwen_hf
```

**Option 3: Use GGUF for inference only**
```python
# Load teacher with llama.cpp (inference-only)
from llama_cpp import Llama

llama = Llama(model_path="~/model/Qwen3.5-0.8B-BF16.gguf", n_gpu_layers=-1)
# Can't use for KD training, but works for inference comparison
```

**Recommendation**: Use Option 1 (HuggingFace) for simplicity.

---

## Student Model Sizes

Choose based on your target hardware:

| Layers | Hidden | Heads | Params | Speed (RTX 2050) | Quality vs Teacher |
|--------|--------|-------|--------|-----------------|-------------------|
| 3 | 128 | 2 | 30M | 200+ samples/s | ~70% |
| 5 | 256 | 4 | 100M | 50-80 samples/s | ~85% |
| 8 | 384 | 6 | 250M | 20-30 samples/s | ~95% |

### My Recommendation for RTX 2050:
**5 layers × 256 hidden = 100M params**
- Good quality (85-90% of teacher)
- Good speed (50-80 samples/sec)
- Fits comfortably in 4GB VRAM

---

## Troubleshooting

| Error | Solution |
|-------|----------|
| CUDA OOM | Reduce batch_size or max_seq_length |
| Model not found | Run `python setup_qwen_distill.py --download` |
| Very slow training | Enable `use_gradient_checkpointing = True` |
| Loss not decreasing | Increase learning_rate to 1e-3 or 1.5e-3 |
| Generation quality poor | Increase `temperature` to 4.0-5.0 |
| Tokenizer mismatch | Ensure `teacher_model_name` matches downloaded model |

---

## Advanced: Quantization

After training, compress further:

```python
# INT8 quantization (8x compression)
from bitsandbytes import quantize_model

quantized = quantize_model(student, quant_type="int8")
torch.save(quantized.state_dict(), "checkpoints/student_int8.pt")
# Result: 100M → 12.5M, ~92% quality retained

# NF4 quantization (4-bit, even smaller)
from transformers import BitsAndBytesConfig

config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_quant_type="nf4",
)
# Result: 100M → 6.25M
```

---

## Integration with DiffuMoE

Once you have the student checkpoint:

```python
from qwen_distill import QwenStudentModel, QwenDistillationConfig

# Load distilled student as backbone
checkpoint = torch.load("checkpoints/student_final.pt")
config = QwenDistillationConfig()
student = QwenStudentModel(config)
student.load_state_dict(checkpoint['model_state_dict'])

# Use as base for MoE
class DiffuMoEQwen(nn.Module):
    def __init__(self, student_checkpoint):
        super().__init__()
        self.backbone = student  # Distilled Qwen
        self.expert_pool = MixtureOfExperts(num_experts=4)
        # ... rest of DiffuMoE
```

---

## Files Summary

| File | Purpose |
|------|---------|
| `qwen_distill.py` | Main distillation trainer |
| `qwen_inference.py` | Inference & evaluation |
| `setup_qwen_distill.py` | Setup automation |
| `checkpoints/` | Student model checkpoints |
| `data/` | Training data |
| `logs/` | Training metrics & logs |

---

## Command Reference

```bash
# Full setup
python setup_qwen_distill.py --all

# Training
python qwen_distill.py

# Inference
python qwen_inference.py --checkpoint checkpoints/student_final.pt --eval

# Speed test
python qwen_inference.py --speed

# Custom generation
python qwen_inference.py --prompt "Your custom prompt here"
```

---

## Expected Results

After 2000 training steps (4-6 hours):

- **Student Perplexity**: 12-15
- **Teacher Perplexity**: 8-10
- **Top-5 Agreement**: 85-92%
- **Inference Speed**: 50-80 samples/sec
- **Model Size**: 100M params (400MB FP32, 200MB FP16)

---

## Next Steps

1. ✓ Run `python setup_qwen_distill.py --all`
2. ✓ Train: `python qwen_distill.py`
3. ✓ Evaluate: `python qwen_inference.py --eval`
4. ✓ Integrate with DiffuMoE as backbone
5. ✓ Quantize to INT8 for deployment

Good luck! 🚀
